import javalib.funworld.*;
import javalib.worldimages.*;
import javalib.colors.*;
import javalib.worldcanvas.*;

public class TriSwitchBB extends World {
    final int size = 400;
    

    @Override
    public WorldImage makeImage() {
        return null;
    }
    
    public TriSwitchBB onTick() {
        return null;
    }
    public TriSwitchBB onKeyEvent(String ke) {
        return null;
        
    }
    public WorldEnd endGame() {
        return lastWorld;
        
    }
    
}