package mymap;

/**
 * 
 * @author Nicholas Scheuring nscheu scheuring.n@husky.neu.edu
 * @version 3500 Assignment 4 : 1/28/14
 * @param <K>
 *            - The key stored in the map
 * @param <V>
 *            - the the value stored in the map
 */
public abstract class Alist<K, V> extends MyMap<K, V> {
}