package mymap;


//import java.util.Collections;
import java.util.ArrayList;
import java.util.Comparator;


//import mymap.KCompare;import mymap.KeyIterator;

//import mymap.Node;import mymap.StrCompare;



import tester.*;
/**
 * 
 * @author Nicholas Scheuring nscheu scheuring.n@husky.neu.edu
 * @version 3500 Assignment 4 : 1/28/14
 * @param <K>
 * @param <K>
 * 
 */
public class Examples<K> extends Tester {
    /**
     * Constructor for ExamplesMyMap testing class
     */
    public Examples() {
        // Default Constructor
        intarr0.add(1);
        intarr1.add(1);
        //intarr2 = intarr1;
        //intarr2.add(2);

        strarr1.add("1");
        strarr2.add("1");
        strarr2.add("2");
    }

    private Comparator<String> strComp = new StrCompare();
    private Comparator<Integer> intComp = new IntCompare();
    //private Comparator<K> kComp = new KCompare<K>();
    @SuppressWarnings("unchecked")
    private MyMap<String, String> mapMT = (MyMap<String, String>) MyMap
            .empty(strComp);

    // Example Nodes
    private Node<String, String> node1 = new Node<String, String>(
                    "1", "one", mapMT, mapMT, strComp, false);
    private Node<String, String> node2 = new Node<String, String>(
            "2", "two", node1, mapMT, strComp, true);
    private Node<String, String> node4 = new Node<String, String>(
            "4", "four", mapMT, mapMT, strComp, true);
    private Node<String, String> node3 = new Node<String, String>(
            "3", "three", node2, node4, strComp, false);
    /*
    private MyMap<String, String> node5 = mapMT.include("5", "five");
    private MyMap<String, String> node6 = mapMT.include("6", "six");
    private MyMap<String, String> node7 = mapMT.include("7", "seven");
    private MyMap<String, String> node8 = mapMT.include("8", "eight");
    private MyMap<String, String> node9 = mapMT.include("9", "nine");
    private MyMap<String, String> node10 = mapMT.include("10", "ten");
    */
    //private MyMap<String, String> map100 = new Node("5", "root", node1, node6,
    //        strComp, true);
    //private MyMap<String, String> map101 = new Node("6", "root", node1, node7,
    //        strComp, true);

    private MyMap<String, String> map1 = mapMT.include("1", "one");
    private MyMap<String, String> map2 = map1.include("2", "two");
    private MyMap<String, String> map22 = map1.include("2", "two");
    private MyMap<String, String> mapdouble = map2.include("2", "two");
    private MyMap<String, String> map3 = map2.include("3", "three");
    // private MyMap<String, String> map5 = map3.include("5", "five", map3,
    // mapMT);
    // private MyMap<String, String> map4 = map3.include("5", "five", map3,
    // map5);

    @SuppressWarnings("unchecked")
    private MyMap<Integer, String> map00 = (MyMap<Integer, String>) MyMap
            .empty(intComp);
    private MyMap<Integer, String> map01 = map00.include(1, "uno");
    private MyMap<Integer, String> map02 = map01.include(2, "dos");
    private MyMap<String, String> map1flip = mapMT.include("2", "two");
    //private MyMap<String, String> map2flip = map1flip.include("1", "one");
    // private MyMap<String, String> map1bob = mapMT.include("1", "bob", mapMT);

    // ArrayList examples
    //private ArrayList<String> strarrMT = new ArrayList<String>();
    private ArrayList<String> strarr1 = new ArrayList<String>();
    private ArrayList<String> strarr2 = new ArrayList<String>();

    private ArrayList<Integer> intarr0 = new ArrayList<Integer>();
    private ArrayList<Integer> intarr1 = new ArrayList<Integer>();
    //private ArrayList<Integer> intarr2 = new ArrayList<Integer>();

    /**
     * Test constructor Empty(c) calls Empty()
     * @param t - the Tester Object
     */
    public void testEmpty(Tester t) {
        // MyMap tests
        //t.checkExpect(MyMap.empty() instanceof MyMap, true);
        t.checkExpect(mapMT instanceof MyMap, true);
        t.checkExpect(map00 instanceof MyMap, true);
        //t.checkExpect(!(MyMap.empty() instanceof MyMap), false);
        t.checkExpect(!(mapMT instanceof MyMap), false);
        t.checkExpect(!(map00 instanceof MyMap), false);
    }
    /**
     * Test constructor Empty(c) calls Empty()
     * @param t - The Tester object
     */
    public void testEmptyC(Tester t) {
        // MyMap tests
        /*t.checkExpect(MyMap.empty() instanceof MyMap, true);
        t.checkExpect(MyMap.empty() instanceof MyMap, true);
        t.checkExpect(MyMap.empty() instanceof MyMap, true);
        t.checkExpect(!(MyMap.empty() instanceof MyMap), false);
        */
    }
    /**
     * Test constructor Empty(c) calls Empty()
     * @param t - The Tester object
     */
    public void testInclude(Tester t) {
        // MyMap tests
        t.checkExpect(
                mapMT.include("one", "ones") instanceof MyMap,
                true);
        t.checkExpect(
                !(mapMT.include("one", "ones") instanceof MyMap),
                false);
        t.checkExpect(map00.include(1, "unos") instanceof MyMap, true);
        t.checkExpect(!(map00.include(1, "unos") instanceof MyMap), false);
    }
    /**
     * Tests the isEmpty() method
     * @param t - The Tester object
     */
    public void testIsEmpty(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.isEmpty(), true);
        t.checkExpect(map00.isEmpty(), true);
        t.checkExpect(!mapMT.isEmpty(), false);
        t.checkExpect(map1.isEmpty(), false);
        t.checkExpect(!map1.isEmpty(), true);
    }
    /**
     * Tests the size() method
     * @param t - The Tester object
     */
    public void testSize(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.size(), 0);
        t.checkExpect(map1.size(), 1);
        t.checkExpect(map2.size(), 2);
        t.checkExpect(map3.size(), 3);
        t.checkExpect(mapdouble.size(), 2);
    }
    /**
     * Tests the containsKey() method
     * @param t - The Tester object
     */
    public void testContainsKey(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.containsKey("1"), false);
        t.checkExpect(map00.containsKey(1), false);
        t.checkExpect(map1.containsKey("1"), true);
        t.checkExpect(map2.containsKey("1"), true);
        t.checkExpect(map3.containsKey("1"), true);
        t.checkExpect(map1.containsKey("9"), false);
        t.checkExpect(map2.containsKey("2"), true);
        t.checkExpect(map2.containsKey("9"), false);
        t.checkExpect(map3.containsKey("2"), true);
        t.checkExpect(map3.containsKey("3"), true);
        t.checkExpect(map3.containsKey("9"), false);
    }
    /**
     * Tests the get() method
     * @param t - The Tester object
     */
    public void testGet(Tester t) {
        // MyMap tests
        //t.checkExpect(mapMT.get("1"), null);
        t.checkExpect(map1.get("1"), "one");
        //t.checkExpect(map1.get("2"), null);
        t.checkExpect(map2.get("2"), "two");
        t.checkExpect(map2.get("1"), "one");
        t.checkExpect(map3.get("1"), "one");
        t.checkExpect(map3.get("2"), "two");
        t.checkExpect(map3.get("3"), "three");
        t.checkExpect(map02.get(2), "dos");
        t.checkExpect(map02.get(1), "uno");
    }
    /**
     * Tests the set() method
     * @param t - The Tester object
     */
    public void testSet(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.set("2", "two"), map1flip);
        // t.checkExpect(map1.set("2", "two"), map2flip);
        // t.checkExpect(map1.set("1", "bob"), map1bob);
    }
    /**
     * Tests the toString() method
     * @param t - The Tester object
     */
    public void testToString(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.toString(), 
                "{...(0 key(s) mapped to value(s))...}");
        t.checkExpect(map1.toString(),
                 "{...(1 key(s) mapped to value(s))...}");
        t.checkExpect(mapdouble.toString(),
                 "{...(2 key(s) mapped to value(s))...}");
    }
    /**
     * Tests the equals() method
     * @param t - The Tester Object
     */
    public void testEquals(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.equals(null), false);
        t.checkExpect(map2.equals(null), false);
        t.checkExpect(map2.equals(map22), true);
        t.checkExpect(mapMT.equals(mapMT), true);
        t.checkExpect(map1.equals(map1), true);
        t.checkExpect(map1.equals(null), false);
        t.checkExpect(map1.equals(map2), false);
    }
    /**
     * Tests the hashCode() method
     * @param t - The Tester object
     */
    public void testHashCode(Tester t) {
        // MyMap tests
        t.checkExpect(mapMT.hashCode(), 0);
        t.checkExpect(map1.hashCode(), 5510753);
    }
    /**
     * Tests the iterator() method
     * @param t - The Tester object
     */
    public void testIterator(Tester t) {
        // MyMap tests
        KeyIterator<Integer> kit = new KeyIterator<Integer>(map00);

        while (kit.hasNext()) {
            System.out.println(kit.next());
        }
        KeyIterator<String> lit = new KeyIterator<String>(mapMT);
        while (lit.hasNext()) {
            System.out.println(lit.next());
        }
        
        KeyIterator<String> mit = new KeyIterator<String>(map2); 
        while (mit.hasNext()) {
            System.out.println(mit.next());
        }
        KeyIterator<Integer> nit = new KeyIterator<Integer>(map02, intComp);
        while (nit.hasNext()) {
            System.out.println(nit.next());
        }
        KeyIterator<Integer> oit = new KeyIterator<Integer>(map00, intComp);
        while (oit.hasNext()) {
            System.out.println(oit.next());
        } 
        try {
            nit.remove();
        }
        catch (Exception e) {
            System.out.println("an exception was correctly thrown in remove");
        }
        
        t.checkExpect(mapMT.iterator(), new KeyIterator<String>(mapMT));
        //t.checkExpect(mapMT.iterator(null), new KeyIterator<String>(mapMT));
        t.checkExpect(map1.iterator(), new KeyIterator<String>(strarr1));
        //t.checkExpect(map2.iterator(), new KeyIterator<String>(map2));
        t.checkExpect(map2.iterator().hasNext(), "2");
        t.checkExpect(map2.iterator().next(), "2");
        
    }
    /**
     * Tests the getKeys() method
     * @param t - The Tester object
     */
    void testGetKeys(Tester t) {
        // MyMap tests

        //t.checkExpect(map00.getKeys(intarr0), intarr0);
        //t.checkExpect(mapMT.getKeys(strarrMT), new ArrayList<String>());
    }
    /**
     * Tests the getAllKeys() method
     * @param t - The Tester object
     */
    void testGetAllKeys(Tester t) {
        // MyMap tests
        //t.checkExpect(mapMT.getAllKeys(), new ArrayList<Integer>());
    }
    /**
     * Tests the containsAllKeys() method
     * @param t - The Tester object
     */
    void testContainsAllKeys(Tester t) {
        // MyMap tests
        //t.checkExpect(mapMT.containsAllKeys(map1, map2), true);
    }
    /**
     * Tests the checkKeys() method
     * @param t - The Tester object
     */
    void testCheckKeys(Tester t) {
        // MyMap tests
    }
    /**
     * Tests the compareKeys() method
     * @param t - The Tester object
     */
    void testCompareKeys(Tester t) {
        // MyMap tests
    }
    /**
     * Black box tests for MyMap
     * @param t - The Tester object
     */
    @SuppressWarnings("unchecked")
    void testBlackBox(Tester t) {
        
        //t.checkExpect(MyMap.empty(strComp), MyMap.empty());
        //t.checkExpect(MyMap.empty().isEmpty(), true);
        t.checkExpect(map00.include(4, "four").isEmpty(), false);
        t.checkExpect(MyMap.empty(strComp).size(), 0);
        t.checkExpect(map01.include(1, "f").size(), map01.size());
        t.checkExpect(map00.include(4, "f").size(), 1 + map00.size());
        t.checkExpect(MyMap.empty(intComp).containsKey(99), false);
        t.checkExpect(map01.include(2, "f").containsKey(2), true);
        t.checkExpect(map00.include(1, "f").containsKey(99), 
                map00.containsKey(99));
        t.checkExpect(map00.include(2, "f").get(2), "f");
        
        //t.checkExpect(map00.include(2, "f").get(4), map00.get(4));
        //t.checkExpect(map01.include(2, "f").get(4), map01.get(4));
        
        t.checkExpect(MyMap.empty(intComp).set(1, "f"), 
                MyMap.empty(intComp).include(1, "f"));
        t.checkExpect(map00.include(1, "f").set(1, "g"), 
                map00.include(1, "g"));
        t.checkExpect(map00.include(1, "f").set(4, "g"), 
                map00.set(4, "g").include(1, "f"));
        //t.checkExpect(map02.toString(), "{...(" + map02.size() + 
        //" key(s) mapped to value(s))...}");
    }
    
    //*************************************************************************
    /**
     * tests - Gets the color of the node
     * @param t - the Tester object
     */
    void testGetColor(Tester t) {
        t.checkExpect(node1.getColor(), false);
    }
    
    /**
     * Tests - Gets the left MyMap
     * @param t - the Tester object
     */
    void testGetLeftMap(Tester t) {
        t.checkExpect(node2.getLeftMap(), node1);
    }
    /**
     * Tests - Gets the right MyMap
     * @param t - the Tester object
     */
    void testGetRightMap(Tester t) {
        t.checkExpect(node3.getRightMap(), node4);
    }
    /**
     * Tests - Gets the Current key
     * @param t - the Tester object
     */
    void testGetKey(Tester t) {
        t.checkExpect(node2.getKey(), "2");
    }
    /**
     * Tests - Gets the Current value
     * @param t - the Tester object
     */
    void testGetValue(Tester t) {
        t.checkExpect(node2.getValue(), "two");
    }
    /**
     * Tests - Gets the key of a child node
     * @param t - the Tester object
     */
    void testGetLeftChildKey(Tester t) {
        t.checkExpect(node2.getLeftChildKey(), "1");
    }
    /**
     * Tests - Gets the key of a child node
     * @param t - the Tester object
     */
    void testGetRightChildKey(Tester t) {
        t.checkExpect(node3.getRightChildKey(), "4");
    }
    /**
     * Tests - Gets the value of a child node
     * @param t - the Tester object
     */
    void testGetLeftChildValue(Tester t) {
        t.checkExpect(node2.getLeftChildValue(), "one");
    }
    /**
     * Tests - Gets the value of a child node
     * @param t - the Tester object
     */
    void testGetRightChildValue(Tester t) {
        t.checkExpect(node3.getRightChildValue(), "four");
    }
}